from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_mysqldb import MySQL
import numpy as np
import pandas as pd
from stable_baselines3 import PPO
from load_env import LoadBalancingEnv
import os

app = Flask(__name__)
app.secret_key = "supersecretkey"

# -----------------------------
# MySQL Configuration
# -----------------------------
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'powergrid_db'

mysql = MySQL(app)

# -----------------------------
# Load Model and Environment
# -----------------------------
env = LoadBalancingEnv(
    r'C:\Users\hrish\Downloads\self_optimizing_power_grid\self_optimizing_power_grid\Synthetic_Load_Balance.csv'
)
MODEL_PATH = os.path.join(os.path.dirname(__file__), "trained_load_balancer_compatible.zip")
model = PPO.load(MODEL_PATH, env=env)

# -----------------------------
# Helper Function
# -----------------------------
def optimize_load(params):
    state = np.array([
        params["load_demand_kwh"] / env.max_load,
        params["transformer_load_percent"] / 100,
        params["hour_of_day"] / 23,
        (params["temperature_c"] + 10) / 60,
        params["humidity_percent"] / 100,
        params["renewable_contribution_percent"] / 30,
        (params["frequency_hz"] - 49.0) / 2.0,
        params["season_code"] / 2
    ], dtype=np.float32)

    action, _ = model.predict(state, deterministic=True)
    new_state, reward, done, truncated, info = env.step(action)

    return {
        "Suggested_Action": float(action[0]),
        "Adjusted_Load_kWh": round(info.get("adjusted_load", np.random.uniform(5, 10)), 2),
        "Transformer_Load_%": round(info.get("transformer_load_percent", np.random.uniform(25, 80)), 2),
        "Reward": round(reward, 2),
        "Overload_Count": int(info.get("overload_count", 0)),
        "Mean_Reward": round(info.get("mean_reward", reward), 2)
    }

# -----------------------------
# ROUTES
# -----------------------------

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s", [username])
        existing_user = cur.fetchone()

        if existing_user:
            cur.close()
            return render_template('signup.html', error="Username already exists!")

        cur.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
        mysql.connection.commit()
        cur.close()

        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            session['username'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="Invalid username or password")

    return render_template('login.html')


@app.route('/home')
def home():
    if 'username' in session:
        return render_template('home.html', username=session['username'])
    else:
        return redirect(url_for('login'))


@app.route('/fraud-detection')
def fraud_detection():
    if 'username' in session:
        return render_template('fraud_detection.html')
    else:
        return redirect(url_for('login'))

# ------------------------------------------------
# ✅ LOAD BALANCING ROUTE (Supports POST + GET)
# ------------------------------------------------
@app.route('/load-balancing', methods=['GET', 'POST'])
def load_balancing():
    if 'username' not in session:
        return redirect(url_for('login'))

    # --- Case 1: Form/JS POST Request ---
    if request.method == 'POST':
        data = request.get_json()
        params = {
            "load_demand_kwh": float(data["load_demand_kwh"]),
            "transformer_load_percent": float(data["transformer_load_percent"]),
            "hour_of_day": int(data["hour_of_day"]),
            "temperature_c": float(data["temperature_c"]),
            "humidity_percent": float(data["humidity_percent"]),
            "renewable_contribution_percent": float(data["renewable_contribution_percent"]),
            "frequency_hz": float(data["frequency_hz"]),
            "season_code": int(data["season_code"])
        }
        result = optimize_load(params)
        return jsonify(result)

    # --- Case 2: Browser GET with URL parameters ---
    elif request.args:
        print("✅ GET parameters detected:", request.args)
        try:
            params = {
                "load_demand_kwh": float(request.args.get("load_demand_kwh")),
                "transformer_load_percent": float(request.args.get("transformer_load_percent")),
                "hour_of_day": int(request.args.get("hour_of_day")),
                "temperature_c": float(request.args.get("temperature_c")),
                "humidity_percent": float(request.args.get("humidity_percent")),
                "renewable_contribution_percent": float(request.args.get("renewable_contribution_percent")),
                "frequency_hz": float(request.args.get("frequency_hz")),
                "season_code": int(request.args.get("season_code"))
            }

            result = optimize_load(params)
            return f"""
            <html>
            <head>
                <title>⚡ Load Optimization Result</title>
                <style>
                    body {{
                        background: linear-gradient(120deg, #1e90ff, #00bfff);
                        color: white;
                        text-align: center;
                        font-family: Arial, sans-serif;
                        padding-top: 50px;
                    }}
                    .card {{
                        background-color: rgba(0,0,0,0.6);
                        margin: auto;
                        width: 400px;
                        padding: 25px;
                        border-radius: 15px;
                    }}
                    p {{ font-size: 18px; }}
                </style>
            </head>
            <body>
                <div class="card">
                    <h2>⚙️ Load Optimization Result</h2>
                    <p><b>Suggested Action:</b> {result['Suggested_Action']}</p>
                    <p><b>Adjusted Load (kWh):</b> {result['Adjusted_Load_kWh']}</p>
                    <p><b>Transformer Load (%):</b> {result['Transformer_Load_%']}</p>
                    <p><b>Reward:</b> {result['Reward']}</p>
                    <p><b>Overload Count:</b> {result['Overload_Count']}</p>
                    <p><b>Mean Reward:</b> {result['Mean_Reward']}</p>
                </div>
            </body>
            </html>
            """
        except Exception as e:
            return f"<h3 style='color:red;'>Error: {e}</h3>"

    # --- Default: just show form ---
    return render_template('load_balancing.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


# -----------------------------
# Run the App
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)

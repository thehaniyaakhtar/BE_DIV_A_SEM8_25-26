import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import spaces

class LoadBalancingEnv(gym.Env):
    """Custom Environment for Power Grid Load Balancing"""
    metadata = {'render.modes': ['human']}

    def __init__(self, data_file='Synthetic_Load_Balance.csv'):
        super(LoadBalancingEnv, self).__init__()

        # Load dataset
        self.data = pd.read_csv(data_file)
        print("🧾 CSV columns detected:", list(self.data.columns))

        # --- Encode string columns manually ---
        # Day of week (Mon=0, Tue=1, ..., Sun=6)
        if 'day_of_week' in self.data.columns:
            day_map = {'Mon': 0, 'Tue': 1, 'Wed': 2, 'Thu': 3, 'Fri': 4, 'Sat': 5, 'Sun': 6}
            self.data['day_of_week'] = self.data['day_of_week'].map(day_map)

        # Season (Winter=0, Summer=1, Monsoon=2)
        if 'season' in self.data.columns:
            season_map = {'Winter': 0, 'Summer': 1, 'Monsoon': 2}
            self.data['season'] = self.data['season'].map(season_map)

        # Substation status (Normal=0, Overload=1)
        if 'substation_status' in self.data.columns:
            status_map = {'Normal': 0, 'Overload': 1}
            self.data['substation_status'] = self.data['substation_status'].map(status_map)

        # Replace NaN (in case of missing string mappings)
        self.data = self.data.fillna(0)

        # --- Identify numeric columns ---
        numeric_cols = self.data.select_dtypes(include=[np.number]).columns.tolist()
        print(f"✅ Numeric columns used: {numeric_cols}")

        if len(numeric_cols) < 8:
            raise ValueError(f"❌ Expected ≥8 numeric columns, found {len(numeric_cols)}")

        self.node_columns = numeric_cols[:8]
        self.num_nodes = len(self.node_columns)

        # --- Compute max load for normalization ---
        self.max_load = self.data[self.node_columns].max().max(skipna=True)
        print(f"✅ Max load detected: {self.max_load:.2f}")

        # --- Define observation & action space ---
        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, -10, 0, 0, 0, 0], dtype=np.float32),
            high=np.array([18.4, 150, 23, 50, 100, 30, 1, 2], dtype=np.float32),
            dtype=np.float32
        )
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(1,), dtype=np.float32)

        # --- Runtime state ---
        self.current_step = 0
        self.overload_count = 0
        self.reward_history = []

    # --------------------------------------------------
    def reset(self, seed=None, options=None):
        """Reset environment."""
        super().reset(seed=seed)
        self.current_step = 0
        self.overload_count = 0
        self.reward_history.clear()
        obs = self._get_obs()
        return obs, {}

    # --------------------------------------------------
    def _get_obs(self):
        """Return the current observation."""
        obs = self.data.loc[self.current_step, self.node_columns].values
        obs = np.nan_to_num(obs, nan=0.0).astype(np.float32)
        return obs

    # --------------------------------------------------
    def step(self, action):
        """Simulate load balancing step."""
        action_value = float(action[0])
        current_loads = self._get_obs()

        # Adjust load values
        adjustment = action_value * 0.05
        new_loads = current_loads * (1 + adjustment)
        new_loads = np.clip(new_loads, self.observation_space.low, self.observation_space.high)

        # Compute reward
        normalized_loads = new_loads / np.maximum(new_loads.mean(), 1e-6)
        balance_score = 1 - np.std(normalized_loads)
        reward = float(balance_score)

        transformer_load_percent = np.mean(new_loads) / self.max_load * 100
        if transformer_load_percent > 100:
            self.overload_count += 1

        self.reward_history.append(reward)
        mean_reward = np.mean(self.reward_history)

        self.current_step += 1
        done = self.current_step >= len(self.data) - 1

        info = {
            "adjusted_load": float(np.mean(new_loads)),
            "transformer_load_percent": float(transformer_load_percent),
            "overload_count": int(self.overload_count),
            "mean_reward": float(mean_reward)
        }

        return new_loads, reward, done, False, info

    # --------------------------------------------------
    def render(self):
        print(f"Step: {self.current_step}, Loads: {self._get_obs()}")
